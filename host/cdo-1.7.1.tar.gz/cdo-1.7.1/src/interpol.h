
void intgridbil(field_t *field1, field_t *field2);
void intgridcon(field_t *field1, field_t *field2);
void interpolate(field_t *field1, field_t *field2);
