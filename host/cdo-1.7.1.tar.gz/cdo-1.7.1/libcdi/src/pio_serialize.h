#ifndef SERIALIZE_PIO_H
#define SERIALIZE_PIO_H
/* switch current namespace to use MPI serialization */
void cdiPioSerializeSetMPI(void);

#endif

/*
 * Local Variables:
 * c-file-style: "Java"
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * show-trailing-whitespace: t
 * require-trailing-newline: t
 * End:
 */
