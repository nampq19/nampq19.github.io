
#include "cdesc.h"

int MPIR_F_sync_reg_cdesc(CFI_cdesc_t* buf)
{
    int err = MPI_SUCCESS;

    /* Intentionally left empty */

    return err;
}
